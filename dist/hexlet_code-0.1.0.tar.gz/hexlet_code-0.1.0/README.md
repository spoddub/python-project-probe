<a href="https://codeclimate.com/github/spoddub/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/0b12be4fd5c0c32c44c2/maintainability" /></a>
